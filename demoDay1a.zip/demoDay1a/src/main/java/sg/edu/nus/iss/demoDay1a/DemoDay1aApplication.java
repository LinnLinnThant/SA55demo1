package sg.edu.nus.iss.demoDay1a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoDay1aApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoDay1aApplication.class, args);
	}

}
