package sg.edu.nus.iss.demoDay1a.controller;
import org.springframework.beans.factory.annotation.Value;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import sg.edu.nus.iss.demoDay1a.model.Person;
import sg.edu.nus.iss.demoDay1a.service.PersonService;

@Controller
public class PersonController {
    private List<Person> personList= new ArrayList<Person>();

    @Autowired
    PersonService personService;

    @Value("${welcome.message}")
    private String welcomeMessage;


    @GetMapping(value={"/","/home"})
    public String index(Model model){
        model.addAttribute("message", welcomeMessage);
        return "home";
    }
}
