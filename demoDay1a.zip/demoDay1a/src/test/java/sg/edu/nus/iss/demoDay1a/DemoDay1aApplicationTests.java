package sg.edu.nus.iss.demoDay1a;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoDay1aApplicationTests {

	@Test
	void contextLoads() {
	}

}
